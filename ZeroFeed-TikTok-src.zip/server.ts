import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Helper to extract hash from jazzdrive URL
function hashFromUrl(u: string): string {
  const m = String(u || '').match(/\/share\/([A-Za-z0-9_-]+)/);
  return m ? m[1] : '';
}

function findStr(o: any, test: (s: string) => boolean): string {
  if (typeof o === 'string') return test(o) ? o : '';
  if (o && typeof o === 'object') {
    for (const k of Object.keys(o)) {
      const r = findStr(o[k], test);
      if (r) return r;
    }
  }
  return '';
}

// Proxy endpoint to resolve JazzDrive share link to direct video
app.post('/api/jazzdrive/resolve', async (req, res) => {
  try {
    const { shareUrl } = req.body;
    const hash = hashFromUrl(shareUrl);
    if (!hash) {
      return res.status(400).json({ error: 'Invalid share link format' });
    }

    const jd = 'https://cloud.jazzdrive.com.pk';
    const api = `${jd}/sapi/media/set?action=get&items=true&thumbnaildimensions=true&shared=true&key=${encodeURIComponent(hash)}`;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);

    const jdRes = await fetch(api, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Referer': `${jd}/share/${hash}`,
        'Origin': jd,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      body: JSON.stringify({ data: {} }),
      signal: controller.signal
    });
    clearTimeout(timer);

    if (!jdRes.ok) {
      return res.status(jdRes.status).json({ error: `JazzDrive responded with HTTP ${jdRes.status}` });
    }

    const data = await jdRes.json();
    const videoUrl = findStr(data, (s) => /^https?:\/\//.test(s) && s.includes('/sapi/download/video'))
      || findStr(data, (s) => /^https?:\/\//.test(s) && s.includes('/sapi/download/') && !/thumb/i.test(s));
    
    const poster = findStr(data, (s) => /^https?:\/\//.test(s) && s.includes('/sapi/download/') && /thumb/i.test(s));

    if (!videoUrl) {
      return res.status(404).json({ error: 'Video stream URL not found in JazzDrive response' });
    }

    return res.json({ success: true, url: videoUrl, poster: poster || '' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Error resolving JazzDrive link' });
  }
});

// Proxy endpoint to fetch remote feed.json
app.get('/api/feed', async (req, res) => {
  try {
    const targetUrl = (req.query.url as string) || 'https://salmanbot248.github.io/jazz-24-7-bot-tg/feed.json';
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(targetUrl + (targetUrl.includes('?') ? '&' : '?') + 't=' + Date.now(), {
      signal: controller.signal,
      headers: { 'User-Agent': 'ZeroFeed-TikTok/2.0' }
    });
    clearTimeout(timer);

    if (!response.ok) {
      throw new Error(`Feed HTTP ${response.status}`);
    }
    const data = await response.json();
    return res.json(data);
  } catch (err: any) {
    return res.status(502).json({ error: err.message || 'Failed to fetch feed' });
  }
});

app.use(express.static(path.resolve(__dirname, 'public')));

// Explicit download endpoints with native Android MIME types & attachment headers
app.get('/api/download/apk', (_req, res) => {
  const p1 = path.resolve(__dirname, 'public', 'ZeroFeed-TikTok.apk');
  const p2 = path.resolve(__dirname, 'src', 'ZeroFeed-TikTok.apk');
  const target = fs.existsSync(p1) ? p1 : p2;
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="ZeroFeed-TikTok.apk"');
  res.sendFile(target);
});

app.get('/api/download/aab', (_req, res) => {
  const p1 = path.resolve(__dirname, 'public', 'ZeroFeed-TikTok.aab');
  const p2 = path.resolve(__dirname, 'src', 'ZeroFeed-TikTok.aab');
  const target = fs.existsSync(p1) ? p1 : p2;
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', 'attachment; filename="ZeroFeed-TikTok.aab"');
  res.sendFile(target);
});

app.get('/api/download/zip', (_req, res) => {
  const target = path.resolve(__dirname, 'public', 'ZeroFeed-TikTok-src.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="ZeroFeed-TikTok-src.zip"');
  res.sendFile(target);
});

// Standalone Direct Mobile Download Hub Page (Opens directly outside iframe)
app.get('/download', (_req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="ur">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Download ZeroFeed TikTok APK & AAB</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background:#0a0a0a; color:#fff; min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px; text-align:center; }
    .card { background:#161616; border:1px solid #282828; border-radius:24px; padding:28px 20px; max-width:440px; width:100%; box-shadow:0 10px 40px rgba(0,0,0,0.8); }
    .badge { display:inline-block; font-size:11px; font-weight:800; padding:4px 12px; border-radius:20px; background:rgba(0,242,254,0.15); color:#00f2fe; margin-bottom:12px; border:1px solid rgba(0,242,254,0.3); }
    h1 { font-size:22px; font-weight:900; margin-bottom:6px; letter-spacing:-0.02em; }
    p.desc { font-size:13px; color:#aaa; margin-bottom:24px; line-height:1.5; }
    .btn { display:flex; align-items:center; justify-content:center; gap:10px; width:100%; padding:14px; border-radius:14px; font-size:14px; font-weight:800; text-decoration:none; margin-bottom:12px; transition:transform 0.1s; }
    .btn:active { transform:scale(0.97); }
    .btn-apk { background:#fe0979; color:#fff; box-shadow:0 4px 20px rgba(254,9,121,0.4); }
    .btn-aab { background:#f59e0b; color:#000; box-shadow:0 4px 20px rgba(245,158,11,0.3); }
    .btn-zip { background:#222; color:#fff; border:1px solid #333; }
    .note { margin-top:20px; font-size:11px; color:#777; line-height:1.6; border-top:1px solid #222; padding-top:16px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">DIRECT DOWNLOAD READY</div>
    <h1>ZeroFeed TikTok App</h1>
    <p class="desc">Neeche diye gaye buttons par click karke direct apne phone me file save karein:</p>
    
    <a href="/api/download/apk" class="btn btn-apk" download="ZeroFeed-TikTok.apk">
      📱 Download ZeroFeed-TikTok.apk
    </a>
    
    <a href="/api/download/aab" class="btn btn-aab" download="ZeroFeed-TikTok.aab">
      📦 Download ZeroFeed-TikTok.aab
    </a>
    
    <a href="/api/download/zip" class="btn btn-zip" download="ZeroFeed-TikTok-src.zip">
      📁 Download Complete Source (.zip)
    </a>

    <div class="note">
      💡 <b>Mobile Tip:</b> APK download hone ke baad Notification bar me click karke <b>Install</b> karein. Agar "Install unknown apps" pooche toh allow kar dein.
    </div>
  </div>
</body>
</html>`);
});

async function main() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ZeroFeed TikTok server running on http://0.0.0.0:${PORT}`);
  });
}

main().catch(console.error);
