import os
import zipfile

def make_zip():
    root_dir = os.getcwd()
    output_zip = os.path.join(root_dir, 'public', 'ZeroFeed-TikTok-src.zip')
    os.makedirs(os.path.join(root_dir, 'public'), exist_ok=True)
    
    exclude_dirs = {'node_modules', '.git', '.cache', 'dist/cache'}
    exclude_files = {'ZeroFeed-TikTok-src.zip'}

    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            rel_root = os.path.relpath(root, root_dir)
            if rel_root == '.':
                parts = []
            else:
                parts = rel_root.split(os.sep)

            # skip excluded dirs
            if any(p in exclude_dirs for p in parts):
                continue

            for file in files:
                if file in exclude_files:
                    continue
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, root_dir)
                try:
                    zipf.write(file_path, rel_path)
                except Exception as e:
                    print(f"Skipping {file_path}: {e}")

    size_mb = os.path.getsize(output_zip) / (1024 * 1024)
    print(f"Successfully created: {output_zip} ({size_mb:.2f} MB)")

if __name__ == '__main__':
    make_zip()
