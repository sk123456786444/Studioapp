import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Package, 
  Smartphone, 
  FileCode2, 
  CheckCircle2, 
  ExternalLink, 
  Terminal, 
  Layers, 
  Sparkles,
  Play,
  Copy,
  Check
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  isOpen,
  onClose,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'source' | 'apk' | 'aab' | 'pwa'>('source');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState<string | null>(null);

  if (!isOpen) return null;

  const downloadFile = async (url: string, filename: string) => {
    setIsDownloading(filename);
    onToast(`${filename} download tayyar ho raha hai... ⏳`);
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error('Download failed');
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(blobUrl);
      onToast(`✅ ${filename} download shuru ho gaya!`);
    } catch {
      // Fallback: direct window.open or location.href
      window.open(url, '_blank');
      onToast(`Naye tab me download khol diya gaya!`);
    } finally {
      setIsDownloading(null);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(label);
    onToast(`${label} copy ho gaya! 📋`);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 animate-fade-in select-none text-left"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] text-white"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00f2fe] via-[#fe0979] to-amber-400 flex items-center justify-center text-black font-black shadow-lg">
              <Download className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base">Download & Export App</h3>
              <p className="text-[11px] text-emerald-400 font-semibold">.apk • .aab • src file ready</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/40 px-2 pt-2 gap-1 overflow-x-auto scrollbar-none">
          {[
            { id: 'source', label: '1. Source ZIP (.zip)', icon: <FileCode2 className="w-3.5 h-3.5 text-[#00f2fe]" /> },
            { id: 'apk', label: '2. Android APK (.apk)', icon: <Smartphone className="w-3.5 h-3.5 text-[#fe0979]" /> },
            { id: 'aab', label: '3. Play Store (.aab)', icon: <Package className="w-3.5 h-3.5 text-amber-400" /> },
            { id: 'pwa', label: '4. Instant Phone App', icon: <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-2.5 rounded-t-xl text-xs font-bold transition-all whitespace-nowrap border-b-2 ${
                activeTab === tab.id
                  ? 'border-[#00f2fe] text-white bg-neutral-800/60'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* TAB 1: SOURCE ZIP */}
          {activeTab === 'source' && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 bg-gradient-to-r from-neutral-950 to-neutral-900 border border-neutral-800 rounded-2xl">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                      <FileCode2 className="w-4 h-4 text-[#00f2fe]" />
                      ZeroFeed-TikTok-src.zip
                    </h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Mukammal source code (React, Vite, Tailwind, Capacitor Android, GitHub Workflows)
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                    Ready (0.66 MB)
                  </span>
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => downloadFile('/api/download/zip', 'ZeroFeed-TikTok-src.zip')}
                    disabled={isDownloading === 'ZeroFeed-TikTok-src.zip'}
                    className="w-full py-3 bg-gradient-to-r from-[#00f2fe] to-[#fe0979] text-black font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg hover:opacity-95 active:scale-95 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 stroke-[3]" />
                    {isDownloading === 'ZeroFeed-TikTok-src.zip' ? 'Download Ho Raha Hai...' : 'Download Source Code (.ZIP) Abhi Karein'}
                  </button>

                  <a
                    href="/download"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-[11px] rounded-xl flex items-center justify-center gap-1.5 border border-neutral-700 transition-all text-center"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-[#00f2fe]" />
                    Naye Tab / Chrome me Download Kholein
                  </a>
                </div>
              </div>

              <div className="space-y-2 text-xs text-neutral-300">
                <h5 className="font-bold text-white flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Is ZIP file ke andar kya shamil hai?
                </h5>
                <ul className="space-y-1.5 pl-5 list-disc text-neutral-400 text-[11px]">
                  <li><b className="text-white">/android:</b> Complete native Android Studio project files (Gradle, Manifest, Java).</li>
                  <li><b className="text-white">/src:</b> TikTok player, gestures, auto-scroll, comments, uploads, sounds.</li>
                  <li><b className="text-white">/.github/workflows/build-apk-aab.yml:</b> GitHub Actions runner file for .apk and .aab generation.</li>
                  <li><b className="text-white">capacitor.config.json:</b> App ID, JazzDrive navigation, and plugins setup.</li>
                  <li><b className="text-white">server.ts:</b> Express full-stack proxy for JazzDrive streams.</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 2: ANDROID APK */}
          {activeTab === 'apk' && (
            <div className="space-y-4 animate-fade-in text-xs">
              {/* Direct APK Download */}
              <div className="p-4 bg-gradient-to-r from-neutral-950 to-neutral-900 border border-neutral-800 rounded-2xl">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-[#fe0979]" />
                      ZeroFeed-TikTok.apk
                    </h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Direct Android Package file. Phone me download karke install karein.
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                    In /src & /public
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 mb-3">
                  📁 <b>File Section me:</b> Ye file <code className="text-[#00f2fe] font-mono">/src/ZeroFeed-TikTok.apk</code> me bhi maujood hai!
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => downloadFile('/api/download/apk', 'ZeroFeed-TikTok.apk')}
                    disabled={isDownloading === 'ZeroFeed-TikTok.apk'}
                    className="w-full py-3 bg-[#fe0979] hover:bg-[#e0086a] disabled:opacity-50 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 stroke-[3]" />
                    {isDownloading === 'ZeroFeed-TikTok.apk' ? 'Download Ho Raha Hai...' : 'Download ZeroFeed-TikTok.apk (Direct)'}
                  </button>

                  <a
                    href="/download"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-[11px] rounded-xl flex items-center justify-center gap-1.5 border border-neutral-700 transition-all text-center"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-[#00f2fe]" />
                    Naye Tab / Chrome me Download Kholein (Recommended)
                  </a>
                </div>
              </div>

              <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Package className="w-4 h-4 text-emerald-400" />
                  GitHub Actions se Re-build (Automated)
                </div>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Aapke project me hum ne <code className="text-white bg-neutral-800 px-1 py-0.5 rounded">.github/workflows/build-apk-aab.yml</code> laga di hai jo GitHub cloud par APK banati hai:
                </p>

                <ol className="space-y-1.5 pl-4 list-decimal text-neutral-300 text-[11px] pt-1">
                  <li>Code GitHub par push karein.</li>
                  <li>GitHub par <b>Actions</b> tab me jayein.</li>
                  <li><b>"Build ZeroFeed TikTok APK & AAB"</b> par click karke <b>"Run workflow"</b> dabayein.</li>
                </ol>
              </div>

              <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-[#00f2fe]" />
                    Option B: Computer / Android Studio par Build Karein
                  </span>
                  <button
                    onClick={() => copyToClipboard('cd android && ./gradlew assembleDebug', 'APK Command')}
                    className="flex items-center gap-1 text-[11px] text-[#00f2fe] hover:underline"
                  >
                    {copiedCmd === 'APK Command' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    Copy
                  </button>
                </div>
                <div className="bg-neutral-900 p-2.5 rounded-xl font-mono text-[11px] text-neutral-200 border border-neutral-800">
                  cd android<br />
                  ./gradlew assembleDebug
                </div>
                <p className="text-neutral-400 text-[11px]">
                  Output APK location: <code className="text-white">android/app/build/outputs/apk/debug/app-debug.apk</code>
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: PLAY STORE AAB */}
          {activeTab === 'aab' && (
            <div className="space-y-4 animate-fade-in text-xs">
              {/* Direct AAB Download */}
              <div className="p-4 bg-gradient-to-r from-neutral-950 to-neutral-900 border border-neutral-800 rounded-2xl">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                      <Package className="w-4 h-4 text-amber-400" />
                      ZeroFeed-TikTok.aab
                    </h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Android App Bundle (Google Play Console upload format).
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                    In /src & /public
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 mb-3">
                  📁 <b>File Section me:</b> Ye file <code className="text-[#00f2fe] font-mono">/src/ZeroFeed-TikTok.aab</code> me bhi maujood hai!
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => downloadFile('/api/download/aab', 'ZeroFeed-TikTok.aab')}
                    disabled={isDownloading === 'ZeroFeed-TikTok.aab'}
                    className="w-full py-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 stroke-[3]" />
                    {isDownloading === 'ZeroFeed-TikTok.aab' ? 'Download Ho Raha Hai...' : 'Download ZeroFeed-TikTok.aab (Direct)'}
                  </button>

                  <a
                    href="/download"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-[11px] rounded-xl flex items-center justify-center gap-1.5 border border-neutral-700 transition-all text-center"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                    Naye Tab / Chrome me Download Kholein
                  </a>
                </div>
              </div>

              <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Package className="w-4 h-4 text-amber-400" />
                  Google Play Store App Bundle (.aab) Guide
                </div>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Google Play Store par app publish karne ke liye <b>.aab (Android App Bundle)</b> format zaroori hota hai. Humne GitHub Actions aur Gradle dono me iska support shamil kar diya hai.
                </p>

                <div className="bg-neutral-900 p-2.5 rounded-xl font-mono text-[11px] text-neutral-200 border border-neutral-800 flex items-center justify-between">
                  <span>cd android && ./gradlew bundleRelease</span>
                  <button
                    onClick={() => copyToClipboard('cd android && ./gradlew bundleRelease', 'AAB Command')}
                    className="text-[#00f2fe]"
                  >
                    {copiedCmd === 'AAB Command' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <p className="text-neutral-400 text-[11px]">
                  Output AAB location: <code className="text-white">android/app/build/outputs/bundle/release/app-release.aab</code>
                </p>
              </div>

              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-[11px] text-amber-300">
                💡 GitHub Actions workflow me jab aap <b>"Run workflow"</b> karenge toh wo automatically <b>.apk aur .aab dono</b> aik sath build karke download link bana dega!
              </div>
            </div>
          )}

          {/* TAB 4: INSTANT PHONE APP */}
          {activeTab === 'pwa' && (
            <div className="space-y-4 animate-fade-in text-xs">
              <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  Bina Computer ke Phone par Install Karein (Direct)
                </div>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Agar aapke paas computer nahi hai, tab bhi aap is app ko apne Android phone me TikTok app ki tarah save kar sakte hain:
                </p>

                <ol className="space-y-2 pl-4 list-decimal text-neutral-300 text-[11px] pt-1">
                  <li>Apne phone ke <b>Google Chrome</b> browser me ye link open karein.</li>
                  <li>Upar right corner par <b>3 Dots (⋮)</b> menu par click karein.</li>
                  <li><b>"Install App"</b> ya <b>"Add to Home screen"</b> (ہوم اسکرین پر شامل کریں) select karein.</li>
                  <li>Aapke mobile ke home screen par ZeroFeed TikTok ka icon aa jayega aur full screen open hoga!</li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <span className="text-[11px] text-neutral-500">
            Capacitor 7.0 + Android SDK Ready
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition-all active:scale-95"
          >
            Band Karein (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
