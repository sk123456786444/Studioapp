package com.salman.zerofeed;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
